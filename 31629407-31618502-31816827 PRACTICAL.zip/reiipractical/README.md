# Maida <img src="https://raw.githubusercontent.com/adnanhyder/classified-html-bootstrap/master/img/logo.png">

Maida Classified
Demo link 
<a href="https://blog.helpyea.com/maidaclassified/">Here</a>

 Maida Classified Template is designed &amp; developed using Bootstrap 4, jQuery. It’s code ready to use and well commented,it uses all free MIT licences So that you can integrate it with any CMS / Core Websites.

  A fully featured Classified style HTML template for creating stunning listings websites.

  <p>Built on the fast loading Bootstrap 4 framework your new website will be fast loading, responsive and features a world class minimalist design that is optimized for SEO and a brilliant user experience.</p>

 <p>Page speed on google 95+ on mobile & 95+ on desktop, We dont't compromise on slow loading websites </p>


  <p>Let the Multipurpose listing begin!</p>


 <h3>Maida Classified – Easy Buy &amp; Sell Directory Listing HTML Template</h3>

  <p>Easy to use, with beautiful clean design and full of features. This is Maida Classified – Easy Buy &amp; Sell Directory Listing HTML template. You get 6 homepage variants, Google map, Auto Complete, Geo Location, 6 types of listing styles and much more! The template is build on the newest Bootstrap 4 and jQuery.</p>


  <h3>17 pages Including Dashboard</h3>
 All you need is your content strategy and a user base to start listing. Each design has a cleverly optimized look and feel to create an awesome directly style listing website access to user for changing cover make profile comment on blog pages.
 <strong>Front End Submissions</strong>
 With Maida Classified  you have a fully functioning front end submission platform ready to roll out. Simply ask your users to Sign In or Register and they can start listing straight away – no additional plugins or hassle of coding anything else by hand. We include all Component to make yor site easily.


  Bootstrap 4
  Bootstrap is the best choice for developing customer experience rich, responsive, mobile first web apps. With most users relying heavily on mobile devices for the majority of their surfing and purchasing behaviour, your new listing buy &amp; sell website needs to acknowledge this customer behaviour – which is exactly why Maida Classified has been developed in Bootstrap 4.

  <p>It’s easy to use, has an awesome responsive grid layout so your website can self-adjust depending on the end device viewing it and includes stacks of free components as well as over 250 icons in font format.</p>


  <h3 id="item-description__features">Features</h3>
  <ul>
    <li>Maida Classified</li>
    <li>W3C Validated</li>
    <li>Fast loading Google Speed Test</li>
    <li>Responsive Iphone Ipad Android Notebook Projectors</li>
    <li>17 Pages</li>
    <li>Single Product Page Masonry Grid implemented </li>
    <li>Bootstrap 4</li>
    <li>Build With CSS</li>
    <li>All Form and content are ready</li>
    <li>Dashboard Included</li>
    <li>Front End Submission Forms</li>
    <li>And Much More</li>
  </ul>

  <h4>Images</h4>
  <a href="https://www.pexels.com" rel="nofollow">Pexels</a>


 <h4>Fonts</h4>
 <a href="https://fontawesome.com/" rel="nofollow">fontawesome</a>

  <p>Note: All photos are for preview only and are not included in the package.</p>

if you find some issue please report <a href="https://helpyea.com">Here</a>
