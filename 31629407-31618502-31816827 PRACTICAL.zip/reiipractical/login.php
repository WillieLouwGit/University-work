<?php 

session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];

		if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
		{

			//read from database
			$query = "select * from users where user_name = '$user_name' limit 1";
			$result = mysqli_query($con, $query);

			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['password'] === $password)
					{

						$_SESSION['user_id'] = $user_data['user_id'];
						header("Location: index.php");
						die;
					}
				}
			}
			
			echo "wrong username or password!";
		}else
		{
			echo "wrong username or password!";
		}
	}

?>


<!DOCTYPE html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <title>REII practical</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="img/logo.png" type="image/gif" sizes="16x16">
    <style>
        .logocolor {
            color: #f00;
        }

        .centercenter {
            position: relative;
            top: 50%;
        }
    </style>
</head>
<body>
    <header class="background-header">
        <div class="container">
            <div class="navigation">
                <nav class="navbar navbar-expand-lg   justify-content-between nav-color zeropadd">
                    <div class="navbar-header ">
                        <a class="navbar-brand zeropadd" href="Startpage.php">
                            <img src="img/logo_200x200.png" alt="logo" class="max-width-60px" />
                        </a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                            <span class="navbar-toggler-icon"></span>
                            <span class="navbar-toggler-icon"></span>
                        </button>
                    </div>
                </nav>

            </div>
        </div>
    </header>

    <div class="content blog">
        <div class="hero-homepage subpage">
            <div class="container wrapping-content">
                <div class="row">
                    <div class="col-12 text-center">
                        <div class="tagline">
                            <h1>Login</h1>
                            <h2>Welcome to sales, please log in</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--Post section-->
        <div class="post-section registerlogin">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">

                        <div class="container formcustom">
                            <div class="col-sm-12 col-md-12 col-xl-10 col-lg-10 ml-auto mr-auto">
                                <ul class="nav nav-pills nav-fill mb-1" id="pills-tab" role="tablist">
                                    <li class="nav-item col-12">
                                        <a class="custom-button phill active"  
                                           role="tab" aria-controls="pills-signin"
                                           aria-selected="true">Login</a>
                                    </li>
                                </ul>
                                <div class="tab-content" id="pills-tabContent">
                                    <div class="tab-pane fade show active" id="pills-signin" role="tabpanel"
                                         aria-labelledby="pills-signin-tab">
                                        <div id="box">
                                            <form method="post">
                                                <div class="form-group">
                                                    <label class="font-weight-bold">User name </label>
                                                    <input type="text" id="text" class="form-control" placeholder="Enter a username" name="user_name"
                                                           required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="font-weight-bold">Password</label>
                                                    <input type="password" name="password" id="text" class="form-control" placeholder="***********" required>
                                                </div>
                                                <div class="form-group">
                                                    <input type="submit" id="button" value="Sign In" class="custom-button">
                                                </div>

                                                <a href="signup.php">Click to Signup</a><br><br>
                                            </form>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <!-- Modal -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
     <script src="js/vendor/jquery-3.4.1.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/main.js"></script
    </body>
    </html>