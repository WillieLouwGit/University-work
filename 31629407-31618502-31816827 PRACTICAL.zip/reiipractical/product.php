<?php
session_start();

	include("connection.php");
	include("functions.php");
    $item_id = $_GET['id'] ?? 1;
?>
<!DOCTYPE html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <title>REII practical</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="img/logo.png" type="image/gif" sizes="16x16">
    <style>
        .logocolor {
            color: #f00;
        }

        .centercenter {
            position: relative;
            top: 50%;
        }
    </style>
</head>


<body>
   <header class="background-header">
  <div class="container">
    <div class="navigation">
      <nav class="navbar navbar-expand-lg   justify-content-between nav-color zeropadd">
        <div class="navbar-header ">
          <a class="navbar-brand zeropadd" href="index.php">
            <img src="img/logo_200x200.png" alt="logo" class="max-width-60px"/>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            <span class="navbar-toggler-icon"></span>
            <span class="navbar-toggler-icon"></span>
          </button>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="nav navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="allads.php">All ads
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="search.php">Search ads
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item dropdown">
              <a  href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                  class="nav-link dropdown-toggle">Pages <i class="fa fa-angle-down"></i></a>
              <ul class="dropdown-menu border-0 shadow">
                <li><a href="aboutus.html" class="dropdown-item">About</a></li>
                <li><a href="terms and conditions.html" class="dropdown-item">Terms and Conditions</a></li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout.php"><i class="fa fa-user" aria-hidden="true"></i>Logout</a>
            </li>
            <li class="nav-item  bordering">
              <a class="nav-link" href="postad.php">Post an Ad</a>
            </li>
          </ul>
        </div>
      </nav>

    </div>
  </div>
</header>
    <div class="content blog">
        <div class="hero-homepage subpage">
            <div class="container wrapping-content">
                <div class="row">
                    <div class="col-12 text-center">
                        <div class="tagline">
                            <h1></h1>
                            <h2>The world is your oister</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--Post section-->
        <div class="post-section blog">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Products</li>
                            </ol>
                        </nav>

                        <?php
                                $sql = "select * from addetails where Ad_id = '$item_id';";
                                $result = mysqli_query($con, $sql);

                                $resultCheck = mysqli_num_rows($result);
                                //remeber prodocut id was inserted.

                                if($resultCheck > 0)
                                {
                                while($row = mysqli_fetch_assoc($result))
                                {
                                echo '<h2 class="styleh2 karma margin_10px">'.$row["Ad_Title"].'</h2>
                                ';

                                }
                                }
                        ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 col-md-12 col-xs-12">
                        <div id="productcarosal" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner height-adjust">

                                <?php
                                $sql = "select * from addetails where Ad_id = '$item_id';";
                                $result = mysqli_query($con, $sql);

                                $resultCheck = mysqli_num_rows($result);
                                //remeber prodocut id was inserted.

                                if($resultCheck > 0)
                                {
                                while($row = mysqli_fetch_assoc($result))
                                {
                                echo '


                                <div class="carousel-item active">
                                    <img class="d-block w-100" src="'.$row["Image_1"].'" alt="First slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="'.$row["Image_2"].' ?? uploads /morbin.jpg" alt="Second slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="'.$row["Image_3"].'" src="uploads/morbin.jpg" alt="Third slide">
                                </div>
                                ';

                                }
                                }
                                ?>


                            </div>
                            <a class="carousel-control-prev coloring" href="#productcarosal" role="button" data-slide="prev">
                                <i class="fa fa-angle-left"></i>
                            </a>
                            <a class="carousel-control-next coloring" href="#productcarosal" role="button" data-slide="next">
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-xs-12 first-height">
                        <div class="boxwedigt margin_10px ">
                            <div class="text-center">
                            <?php
                                $sql = "select * from addetails where Ad_id = '$item_id';";
                                $result = mysqli_query($con, $sql);

                                $resultCheck = mysqli_num_rows($result);
                                //remeber prodocut id was inserted.

                                if($resultCheck > 0)
                                {
                                while($row = mysqli_fetch_assoc($result))
                                {
                                echo ' <h4><i class="fa "></i> <span class="karma">R '.$row["Price"].'</span></h4>
                                        <p class="margin_10px"><a><i class="fa fa-list-alt"></i>'.$row["Category_ID"].'</a></p>
                                ';

                                }
                                }
                        ?>
                                <div class="share-items">
                                    <div class="meta">
                                        <a href="#"><i class="fa fa-facebook-official" aria-hidden="true"> Share</i></a>
                                        <a href="#"><i class="fa fa-instagram" aria-hidden="true"> Share</i></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="boxwedigt margin_10px ">
                            <div class="text-center">
                                <h4><a href="#"><i class="fa"></i> <span class="karma">Buy through New OLX</span></a></h4>
                                <h4><a><span class="karma">OR</span></a></h4>
                                <h4><a><i class="fa fa-user"></i> <span class="karma">Contact the Seller</span></a></h4>
                                <div class="clearfix"></div>
                                <form class="b-send-contact-message">
                                    <input type="text" placeholder="Your Name" class="e-input m-small" name="name" value="">
                                    <input type="text" placeholder="Your Email" class="e-input m-small" name="email" value="">
                                    <input type="text" placeholder="Your Mobile Number" class="e-input m-small" name="mobileNumber" value="">
                                    <textarea name="message" placeholder="Type message"></textarea>
                                    <a class="custom-button" type="submit">Send Message</a>
                                </form>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 col-md-12 col-xs-12">
                        <div class="post-content-wrapper bg-white">
                            <div class="entry-summary boxwedigt ">
                                <div class="row">
                                    <div class="col-sm-3  col-6 col-md-3">
                                        <a href="#"><strong>Location</strong></a>

                                    </div>
                                    <div class="col-sm-3  col-6 col-md-3">

                                      <?php
                                $sql = "select * from addetails where Ad_id = '$item_id';";
                                $result = mysqli_query($con, $sql);

                                $resultCheck = mysqli_num_rows($result);
                                //remeber prodocut id was inserted.

                                if($resultCheck > 0)
                                {
                                while($row = mysqli_fetch_assoc($result))
                                {
                                echo ' <a>'.$row["Location_ID"].'</a>
                                ';

                                }
                                }
                        ?>
                                    </div>

                                </div>
                                <div class="row" class="text-center">
                                    <div class="col-sm-3  col-6 col-md-3" class="text-center">
                                        </h4><a href="#"><strong>Description</strong></a></h4>
                                    </div>
                                </div>
                                <div class="entry-summary">
                                              <?php
                                $sql = "select * from addetails where Ad_id = '$item_id';";
                                $result = mysqli_query($con, $sql);

                                $resultCheck = mysqli_num_rows($result);
                                //remeber prodocut id was inserted.

                                if($resultCheck > 0)
                                {
                                while($row = mysqli_fetch_assoc($result))
                                {
                                echo '   <p>'.$row["Description"].'</p>
                                ';

                                }
                                }
                        ?>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--footer-->
    <footer>
        <!--Newsletter section-->
        <div class="newsletter">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-12">
                        <h2>Newsletter</h2>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <p>Sign up to receive email updates on new recipes.</p>
                    </div>
                    <div class="col-lg-5 col-md-12">
                        <form>
                            <div class="col-sm-12">
                                <div class="row zeromargin zeromargin_form_group">
                                    <div class="form-group col-lg-8 col-sm-12">
                                        <input type="email" class="form-control" placeholder="Your email address here...">
                                    </div>
                                    <div class="form-group col-lg-4 col-sm-12">
                                        <button type="submit" class="whitehover custom-button">Subscribe</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </footer>
    <script src="js/vendor/jquery-3.4.1.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>

