<?php 
session_start();

	include("connection.php");
	include("functions.php");
?>

<!DOCTYPE html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <title>REII practical</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="img/logo.png" type="image/gif" sizes="16x16">
    <style>
        .logocolor {
            color: #f00;
        }

        .centercenter {
            position: relative;
            top: 50%;
        }
    </style>
</head>


<body>
<header class="background-header">
  <div class="container">
    <div class="navigation">
      <nav class="navbar navbar-expand-lg   justify-content-between nav-color zeropadd">
        <div class="navbar-header ">
          <a class="navbar-brand zeropadd" href="index.php">
            <img src="img/logo_200x200.png" alt="logo" class="max-width-60px"/>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            <span class="navbar-toggler-icon"></span>
            <span class="navbar-toggler-icon"></span>
          </button>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="nav navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="allads.php">All ads
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="search.php">Search ads
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item dropdown">
              <a  href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                  class="nav-link dropdown-toggle">Pages <i class="fa fa-angle-down"></i></a>
              <ul class="dropdown-menu border-0 shadow">
                <li><a href="aboutus.html" class="dropdown-item">About</a></li>
                <li><a href="terms and conditions.html" class="dropdown-item">Terms and Conditions</a></li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout.php"><i class="fa fa-user" aria-hidden="true"></i>Logout</a>
            </li>
            <li class="nav-item  bordering">
              <a class="nav-link" href="postad.php">Post an Ad</a>
            </li>
          </ul>
        </div>
      </nav>

    </div>
  </div>
</header>
    <div class="content allads">

        <!--Post section-->
        
        <div class="post-section">
                  <div class="container">
                     <div class="row">
                            <div class="col-lg-12">
                                <h2 class="styleh2 karma text-center">All Ads</h2>
                            </div>
                                    <?php
                                     $sql = "select * from addetails;";
                                        $result = mysqli_query($con, $sql);
                                        $resultCheck = mysqli_num_rows($result);
                                        //remeber prodocut id was inserted.

                                            if($resultCheck > 0)
                                            {
                                                while($row = mysqli_fetch_assoc($result))
                                                {
                                                    echo ' 
                                                               <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12 margin_10px">
                                                                 <div class="post-box">
                                                                            <div class="thumbnail-holder">
                                                                            <a href="product.php?id='.$row["Ad_id"].'">
                                                                            <img src="'.$row["Image_1"].'" alt="iphone">
                                                                            </a>
                                                                            </div>
                                                                            <div class="post-box-content">
                                                                            <h3><a href="product.php?id='.$row["Ad_id"].'">'.$row["Ad_Title"].'</a></h3>
                                                                            </div>
                                                                            <div class="post-category">
                                                                              <a> <i class="fa fa-list-alt"></i>'.$row["Category_ID"].'</a>
                                                                            </div>
                                                                            <div class="post-location">
                                                                              <a> <i class="fa fa-location-arrow"></i>'.$row["Location_ID"].'</a>
                                                                            </div>
                                                                            <div class="post-meta">
                                                                              <i class="fa ">ZAR</i>'.$row["Price"].'
                                                                            </div>
                                                                            <div class="clearfix"></div>

                                                                   </div>
                                                                  </div>';
                                                 }
                                            }
                            
                                    ?>
                        </div>
                     </div>
                   </div>
          </div>




    <!--footer-->
    
    <script src="js/vendor/jquery-3.4.1.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
