<?php
	include 'header.php'
	?>

<form action="search.php" method="post">
	<input type="text" name="search" placeholder="Search">
	<button type="submit" name="submit-search"></button>
</form>

<div class="article container">
	<?php
		$sql = "select * from article";
		$result = mysqli_query($conn,$result);
		$queryR = mysqli_num_rows($results);

		if($queryR>0)
		{ 
			while($row = mysqli_fetch_assoc($result)){
				echo "<div>
						<h3>".$row['a_title']."</h3>
						</div>";
			}
		}
	?>




	//The code below is the action part
<?php
	include bla
?>

<?php
		if(isset($_POST['submit-search']))
		{
			$search = mysqli_real_escape_string($conn, $_POST['search']);
			$sql = "select * from article where a_title is LIKE '%$search%' or a_text is LIKE '%$search%' or a_author is LIKE '%$search%' or a_date is LIKE '%$search%'";
			$result = mysqli_query($conn,$sql);
			$queryResults = mysqli_num_rows($results);
			
			if($queryResults>0){
				while($row = mysqli_fetch_assoc($result)){
					echo "<div>
						<h3>".$row['a_title']."</h3>
						</div>";
				}
			}else {
					echo "There are no results matching your search!";
			}
		}
