<?php
session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$User_FirstName = $_POST['User_FirstName'];
		$UserLastName = $_POST['UserLastName'];
        $UserFullname = $User_FirstName." ".$UserLastName;
        $Ad_Title = $_POST['Ad_Title'];
		$Price = $_POST['Price'];
        $Description = $_POST['Description'];
        $Category_ID = $_POST['Category_ID'];
        $Location_ID = $_POST['Location_ID'];

        $Image1 = $_FILES['Image1'];
	    $fileName = $_FILES['Image1']['name'];
	    $fileTmpName = $_FILES['Image1']['tmp_name'];
	    $fileSize = $_FILES['Image1']['size'];
	    $fileError = $_FILES['Image1']['error'];
	    $fileType = $_FILES['Image1']['type'];

	    $fileExt = explode('.',$fileName);
	    $fileActualExt = strtolower(end($fileExt));

	        $allowed = array('jpg','jpeg','png','pdf');

	        if(in_array($fileActualExt,$allowed))
	        {	if($fileError === 0)
		        {
			        if($fileSize <500000)
			    { 
				    $fileNameNew = uniqid('',true).".".$fileActualExt;
				    $fileDestination1 = 'uploads/'.$fileNameNew;
				    move_uploaded_file($fileTmpName,$fileDestination1);
			    }else { echo "Your file is to big";}
		
		    } else { echo "There was an error";}

	        }else { echo "you cant man, choose different extension";}


            //Second image

        $Image2 = $_FILES['Image2'];
	    $fileName = $_FILES['Image2']['name'];
	    $fileTmpName = $_FILES['Image2']['tmp_name'];
	    $fileSize = $_FILES['Image2']['size'];
	    $fileError = $_FILES['Image2']['error'];
	    $fileType = $_FILES['Image2']['type'];

	    $fileExt = explode('.',$fileName);
	    $fileActualExt = strtolower(end($fileExt));

	        $allowed = array('jpg','jpeg','png','pdf');

	        if(in_array($fileActualExt,$allowed))
	        {	if($fileError === 0)
		        {
			        if($fileSize <500000)
			    { 
				    $fileNameNew = uniqid('',true).".".$fileActualExt;
				    $fileDestination2 = 'uploads/'.$fileNameNew;
				    move_uploaded_file($fileTmpName,$fileDestination2);
			    }else { echo "Your file is to big";}
		
		    } else { echo "There was an error";}

	        }else { echo "you cant man, choose different extension";}


            //Third image
             $Image3 = $_FILES['Image3'];
	    $fileName = $_FILES['Image3']['name'];
	    $fileTmpName = $_FILES['Image3']['tmp_name'];
	    $fileSize = $_FILES['Image3']['size'];
	    $fileError = $_FILES['Image3']['error'];
	    $fileType = $_FILES['Image3']['type'];

	    $fileExt = explode('.',$fileName);
	    $fileActualExt = strtolower(end($fileExt));

	        $allowed = array('jpg','jpeg','png','pdf');

	        if(in_array($fileActualExt,$allowed))
	        {	if($fileError === 0)
		        {
			        if($fileSize <500000)
			    { 
				    $fileNameNew = uniqid('',true).".".$fileActualExt;
				    $fileDestination3 = 'uploads/'.$fileNameNew;
				    move_uploaded_file($fileTmpName,$fileDestination3);
			    }else { echo "Your file is to big";}
		
		    } else { echo "There was an error";}

	        }else { echo "you cant man, choose different extension";}

            $User_Id = $UserFullname;

		if(!empty($User_FirstName) && !empty($UserLastName) && is_numeric($Price) && !empty($Ad_Title))
		{

			//save to database
			$query = "insert into addetails (User_FirstName,UserLastName,Ad_Title,Category_ID,Price,Description,Location_ID,Image_1,Image_2,Image_3,User_Id) values ('$User_FirstName','$UserLastName','$Ad_Title','$Category_ID','$Price','$Description','$Location_ID','$fileDestination1','$fileDestination2','$fileDestination3','$User_Id')";

			mysqli_query($con, $query);

			header("Location: index.php");
			die;
		}else
		{
			echo "Please enter some valid information!";
		}
	}
?>

<!DOCTYPE html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <title>REII practical</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="img/logo.png" type="image/gif" sizes="16x16">
    <style>
        .logocolor {
            color: #f00;
        }

        .centercenter {
            position: relative;
            top: 50%;
        }
    </style>
</head>
<body>

<header class="background-header">
  <div class="container">
    <div class="navigation">
      <nav class="navbar navbar-expand-lg   justify-content-between nav-color zeropadd">
        <div class="navbar-header ">
          <a class="navbar-brand zeropadd" href="index.php">
            <img src="img/logo_200x200.png" alt="logo" class="max-width-60px"/>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            <span class="navbar-toggler-icon"></span>
            <span class="navbar-toggler-icon"></span>
          </button>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="nav navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="allads.php">All ads
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="search.php">Search ads
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item dropdown">
              <a  href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                  class="nav-link dropdown-toggle">Pages <i class="fa fa-angle-down"></i></a>
              <ul class="dropdown-menu border-0 shadow">
                <li><a href="aboutus.html" class="dropdown-item">About</a></li>
                <li><a href="terms and conditions.html" class="dropdown-item">Terms and Conditions</a></li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout.php"><i class="fa fa-user" aria-hidden="true"></i>Logout</a>
            </li>
            <li class="nav-item  bordering">
              <a class="nav-link" href="postad.php">Post an Ad</a>
            </li>
          </ul>
        </div>
      </nav>

    </div>
  </div>
</header>
    
    <div class="content blog">
        <div class="coverimage">
            <img src="img/cover.jpg" class="bannercoveruser" alt="banner">

        </div>
        <!--Post section-->
        <div class="post-section blog">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <div class="container">
                            <div class="row">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-lg-3">
                                            <div class="widget">
             
        
                                            </div>
                                        </div>
                                        <div class="col-lg-9">
                                            <div class="col-sm-12 background_white">
                                                <form method="post" class="row" enctype="multipart/form-data">
                                                    <div class="col-md-6 col-xl-6 col-lg-6 col-sm-12 col-12">
                                                        <div class="form-group ">
                                                            <label class="font-weight-bold">Name</label>
                                                            <input type="text" name ="User_FirstName" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-xl-6 col-lg-6 col-sm-12 col-12">
                                                        <div class="form-group ">
                                                            <label class="font-weight-bold">Surname</label>
                                                            <input type="text" name="UserLastName" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-xl-6 col-lg-6 col-sm-12 col-12">
                                                        <div class="form-group ">
                                                            <label class="font-weight-bold">Ad Title</label>
                                                            <input type="text" name="Ad_Title" class="form-control">
                                                        </div>
                                                    </div>


                                                    <div class="col-md-6 col-xl-6 col-lg-6 col-sm-12 col-12 ">
                                                        <div class="form-group ">
                                                            <label class="font-weight-bold">Category</label>
                                                            <select class="form-control" name="Category_ID">
                                                                <option>Cars</option>
                                                                <option>Computers</option>
                                                                <option>Games</option>
                                                                <option>Electronics</option>
                                                                <option>Watches</option>
                                                                <option>Miscellaneous</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                     <div class="col-md-6 col-xl-6 col-lg-6 col-sm-12 col-12 ">
                                                        <div class="form-group ">
                                                            <label class="font-weight-bold">Location</label>
                                                            <select class="form-control" name="Location_ID">
                                                                <option>Eastern Cape</option>
                                                                <option>Free State</option>
                                                                <option>Gauteng</option>
                                                                <option>KwaZulu-Natal</option>
                                                                <option>Limpopo</option>
                                                                <option>Mpumalanga</option>
                                                                <option>Northen Cape</option>
                                                                <option>North West</option>
                                                            </select>
                                                        </div>
                                                    </div>


                                                    <div class="col-md-6 col-xl-6 col-lg-6 col-sm-12 col-12">
                                                        <div class="form-group ">
                                                            <label class="font-weight-bold">Price</label>
                                                            <input type="text" class="form-control"
                                                                   value="" name="Price" required="">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-xl-12 col-lg-12 col-sm-12 col-12 ">
                                                        <div class="form-group ">
                                                            <label class="font-weight-bold ">Description</label>
                                                            <textarea cols="50" name="Description"
                                                                      class=" sizetextarea col-md-12 col-xl-12 col-lg-12 col-sm-12 col-12"></textarea>
                                                        </div>
                                                    </div>


                                                    <div class="col-md-12 col-xl-12 col-lg-12 col-sm-12 col-12 ">
                                                    <div class="form-group" enctype="multipart/form-data">
                                                        <label class="font-weight-bold">Image 1</label>
                                                        <input class="form-control" type="file" name="Image1">
                                                    </div>
                                                    </div>
                                                    <div class="col-md-12 col-xl-12 col-lg-12 col-sm-12 col-12 ">
                                                    <div class="form-group" enctype="multipart/form-data">
                                                        <label class="font-weight-bold">Image 2</label>
                                                        <input class="form-control" type="file" name="Image2">
                                                    </div>
                                                    </div>
                                                    <div class="col-md-12 col-xl-12 col-lg-12 col-sm-12 col-12 ">
                                                    <div class="form-group" enctype="multipart/form-data">
                                                        <label class="font-weight-bold">Image 3</label>
                                                        <input class="form-control" type="file" name="Image3">
                                                    </div>
                                                    </div>
                                                    <div class="col-md-12 col-xl-12 col-lg-12 col-sm-12 col-12 ">
                                                        <div class="form-group ">
                                                            <input type="submit" value="Submit Ad" class="custom-button">
                                                        </div>
                                                    </div>
                                                    
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 
    <script src="js/vendor/jquery-3.4.1.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
