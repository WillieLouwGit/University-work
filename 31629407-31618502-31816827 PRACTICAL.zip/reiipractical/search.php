<?php 
session_start();

	include("connection.php");
	include("functions.php");
?>

<!DOCTYPE html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <title>REII practical</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="img/logo.png" type="image/gif" sizes="16x16">
    <style>
        .logocolor {
            color: #f00;
        }

        .centercenter {
            position: relative;
            top: 50%;
        }
    </style>
</head>


<body>
<header class="background-header">
  <div class="container">
    <div class="navigation">
      <nav class="navbar navbar-expand-lg   justify-content-between nav-color zeropadd">
        <div class="navbar-header ">
          <a class="navbar-brand zeropadd" href="index.php">
            <img src="img/logo_200x200.png" alt="logo" class="max-width-60px"/>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            <span class="navbar-toggler-icon"></span>
            <span class="navbar-toggler-icon"></span>
          </button>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="nav navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="allads.php">All ads
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="search.php">Search ads
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item dropdown">
              <a  href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                  class="nav-link dropdown-toggle">Pages <i class="fa fa-angle-down"></i></a>
              <ul class="dropdown-menu border-0 shadow">
                <li><a href="aboutus.html" class="dropdown-item">About</a></li>
                <li><a href="terms and conditions.html" class="dropdown-item">Terms and Conditions</a></li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout.php"><i class="fa fa-user" aria-hidden="true"></i>Logout</a>
            </li>
            <li class="nav-item  bordering">
              <a class="nav-link" href="postad.php">Post an Ad</a>
            </li>
          </ul>
        </div>
      </nav>

    </div>
  </div>
</header>   

    <div class="content allads">
        <div class="hero-homepage subpage">
            <div class="container wrapping-content">
                <div class="row">
                    <div class="col-12 text-center">
                        <div class="search_form search-adjust">
                            <form class="row" action="searchtry.php" method="post">
                                <div class="form-group col-lg-4 col-sm-12">
                                    <input type="text" name="search" class="form-control" placeholder="What are you looking for?">
                                </div>
                                <div class="form-group col-lg-4 col-sm-12">
                                    <select class="form-control" name="category">
                                        <option >All Categories</option>
                                        <option>Cars</option>
                                        <option>Computers</option>
                                        <option>Games</option>
                                        <option>Electronics</option>
                                        <option>Watches</option>
                                        <option>Miscellaneous</option>
                                    </select>
                                </div>
                                <div class="form-group col-lg-4 col-sm-12">
                                    <select class="form-control" name="location">
                                        <option>All location</option>
                                        <option>Eastern Cape</option>
                                        <option>Free State</option>
                                        <option>Gauteng</option>
                                        <option>KwaZulu-Natal</option>
                                        <option>Limpopo</option>
                                        <option>Mpumalanga</option>
                                        <option>Northen Cape</option>
                                        <option>North West</option>
                                    </select>
                                </div>

                                <div class="form-group col-lg-12 col-sm-12">
                                    <div id="rangeBox">
                                        <div id="inputRange">
                                            <div id="sliderBox" class="pricerange">
                                                <div class="row">
                                                    <div class="col-12 zeropadd row margin_5px">
                                                        <p class="col-xl-1 col-lg-1 showprice d-none d-sm-none d-md-none d-lg-block d-xl-block">Min Price</p>
                                                        <input type="range" id="slider0to50" class="col-xl-9 col-lg-9 col-md-12" step="5" min="0" max="50000">
                                                        <span class="zeropadd col-xl-2 col-lg-2 col-md-12 row">
                                                            <i class="col-xl-3 col-lg-3 col-md-2 col-sm-2 col-2 fa fa-dollar"></i>
                                                            <input type="number" min="0" class=" form-control col-xl-9 col-lg-9 col-md-10 col-sm-10 col-10" max="50000"
                                                                   placeholder="Min" id="min" name="minimum">
                                                        </span>
                                                    </div>
                                                    <div class="col-12 zeropadd row margin_5px">
                                                        <p class="col-1 showprice d-none d-sm-none d-md-none d-lg-block d-xl-block">Max Price</p>
                                                        <input type="range" id="slider51to100" class="col-xl-9 col-lg-9 col-md-12" step="5" min="50000" max="1000000">
                                                        <span class=" zeropadd col-xl-2 col-lg-2 col-md-12 row">
                                                            <i class="col-xl-3 col-lg-3 col-md-2 col-sm-2 col-2 fa fa-dollar"></i>
                                                            <input type="number" min="50000" class=" form-control col-xl-9 col-lg-9 col-md-10 col-sm-10 col-10 " max="1000000"
                                                                   placeholder="Max" id="max" name="maximum">
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                                <div class="form-group col-lg-12 col-sm-12">
                                    <button type="submit" name="submit-search" class="custom-button">Search</button>
                                </div>

                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <!--Post section-->
    </div>

    <!--footer-->
    
    <script src="js/vendor/jquery-3.4.1.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
