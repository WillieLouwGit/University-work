-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2022 at 04:27 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_sample_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `addetails`
--

CREATE TABLE `addetails` (
  `Ad_id` int(11) NOT NULL,
  `User_FirstName` varchar(30) NOT NULL,
  `UserLastName` varchar(30) NOT NULL,
  `Ad_Title` text NOT NULL,
  `Category_ID` varchar(15) NOT NULL,
  `Price` int(11) NOT NULL,
  `Description` longtext NOT NULL,
  `Location_ID` varchar(15) NOT NULL,
  `Image_1` longtext NOT NULL,
  `Image_2` longtext NOT NULL,
  `Image_3` longtext NOT NULL,
  `User_Id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addetails`
--

INSERT INTO `addetails` (`Ad_id`, `User_FirstName`, `UserLastName`, `Ad_Title`, `Category_ID`, `Price`, `Description`, `Location_ID`, `Image_1`, `Image_2`, `Image_3`, `User_Id`) VALUES
(1, 'Miyah', 'Dotson', '2016 Chevrolet Utility 1.4 Club', 'Cars', 169900, 'This is a 1.4 Petrol engine. The milage is 139 489 km. It is a second-hand bakkie and is the 2016 model.', 'Gauteng', 'uploads/62b6c38da07dd8.57685188.jpg', 'uploads/62b6c38da097e7.96537505.jpg', 'uploads/62b6c38da0aa41.81021050.jpg', 'Miyah Dotson'),
(2, 'Momina', 'Thorpe', '2016 Volkswagen Caddy 1.6 Crew Bus', 'Cars', 209990, 'This is a nice 1.6 Litre crew bus. It is a manual and has a petrol engine', 'Free State', 'uploads/62b6c7d82bd597.01158987.jpg', 'uploads/62b6c7d82c0c75.63860734.jpg', 'uploads/62b6c7d82c5400.36120192.jpg', 'Momina Thorpe'),
(3, 'Romy', 'Olson', ' ProBook 502Z4EA', 'Computers', 49999, 'HP Chromebook 11a 11a-na0002ni 502Z4EA MediaTek MTK 8183 up to 2.0GHz Processor with 2MB Cache, 8x Cores / 4GB DDR4 RAM / 32GB eMMC Storage / 11.6\" HD 1366 x 768 Anti-Glare Display / MediaTek Integrated Graphics / Qualcomm® Atheros 802.11ac Wireless LAN / Bluetooth 4.2 / Chrome OS™ / HP True Vision 720p HD camera with integrated dual array digital microphones / 1x USB Type-A / 1x USB Type-C / 1x microSD media card reader / 1x Headphone and Microphone Audio Combo Jack / No DVD Drive Included / 1 Year Warranty', 'KwaZulu-Natal', 'uploads/62b6c9d3d6f013.91270900.jpg', 'uploads/62b6c9d3d71d38.53231211.jpg', 'uploads/62b6c9d3d74664.11648294.jpg', 'Romy Olson'),
(4, 'Ho', 'Gallegos', 'RAIDMAX i328 TOWER', 'Computers', 3950, 'Motherboard Support: ATX / Micro-ATX / Mini-ITX\r\nExpansion Slots: 7\r\n3.5″ HDD Slots: 2\r\n2.5″ SSD Slots: 2 (Max 4)\r\nI/O Ports: USB3.0 x1 | USB2.0 x2 | HD Audio x2\r\nPre-installed Fans: Rear standard 120mm x1\r\nFront Fan Support: 120mm x3\r\nTop Fan Support: 120mm x2\r\nRear Fan Support: 120mm x1\r\nFront Radiator Support: 240mm\r\nTop Radiator Support: N/A\r\nRear Radiator Support: 120mm\r\nMaximum GPU Length: 330mm\r\nMaximum CPU Cooler Height: 160mm\r\nLeft Side Panel: Steel\r\nRight Side Panel: Tempered Glass\r\nPSU Support: Standard PS2 / Bottom Mounted ATX\r\nDimensions: 39.5 x 20 x 44 cm\r\nWeight: 7200g', 'Limpopo', 'uploads/62b6cacddfec82.07566490.jpg', 'uploads/62b6cacde01049.42182328.jpg', 'uploads/62b6cacde04797.47256664.jpg', 'Ho Gallegos'),
(5, 'Haleema', 'Compton', 'Lenovo IdeaPad 3', 'Computers', 7499, 'Lenovo IdeaPad 3 15ADA6 82KR006BSA AMD Ryzen 3 3250U up to 3.5GHz Processor, 5MB Cache, 2x Cores, 4x Threads / 4GB DDR4 RAM / 512GB Ultra-Fast NVMe SSD / 15.6\" FHD 1920 x 1080 Anti-Glare Display / Integrated AMD Radeon™ Graphics, DirectX 12 Support / No DVD Drive Included / Windows 11 Home (64bit) / HD 720p With Array Microphone / Bluetooth 5.0 / Dual Band 802.11ac Wireless LAN / Fingerprint Reader / 2x 1.5W Speaker With Dolby Audio / Headphone Audio & Microphone Combo Jack / 1x USB 3.2 Type-C / 1x USB 3.2 Type-A / 1x USB 2.0 / 1x HDMI / 1x SD Card reader / Non-backlit Keyboard ', 'Gauteng', 'uploads/62b6cb79ad7e02.10355335.jpg', 'uploads/62b6cb79ada488.88173205.jpg', 'uploads/62b6cb79adcb78.33675248.jpg', 'Haleema Compton'),
(6, 'Samina', 'Tapia', 'Dying Light 2 Stay Human', 'Games', 899, 'The virus won and civilization has fallen back to the Dark Ages. The City, one of the last human settlements, is on the brink of collapse. Use your agility and combat skills to survive, and reshape the world. Your choices matter.', 'Gauteng', 'uploads/62b6cd18e96e67.64849059.jpg', 'uploads/62b6cd18e9ad02.24413822.jpg', 'uploads/62b6cd18e9d867.99107340.jpg', 'Samina Tapia'),
(7, 'Cloe', 'Macgregor', '2019 BMW 8 Series M850i', 'Cars', 549900, 'Very nice BMW. Has a mileage of 2801 km and is a petrol engine.', 'Free State', 'uploads/62c19107bf0d47.54678197.jpg', 'uploads/62c19107bf3e41.53506139.jpg', 'uploads/62c19107bf6323.37259937.jpg', 'Cloe Macgregor');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `user_name`, `password`, `date`) VALUES
(1, 151187915970, 'Miyah Dotson', 'MiyahDotson1', '2022-06-25 08:08:56'),
(2, 84702, 'Momina Thorpe', 'MominaThorpe1', '2022-06-25 08:17:40'),
(3, 310406719522, 'Romy Olson', 'RomyOlson1', '2022-06-25 08:18:02'),
(4, 1496, 'Ho Gallegos', 'HoGallegos1', '2022-06-25 08:18:47'),
(5, 995588, 'Haleema Compton', 'HaleemaCompton1', '2022-06-25 08:19:23'),
(6, 7384126301000711502, 'Samina Tapia', 'SaminaTapia1', '2022-06-25 08:19:56'),
(7, 63773, 'Boyd Rojas', 'BoydRojas1', '2022-06-25 08:20:29'),
(8, 5578062, 'Cloe Macgregor', 'CloeMacgregor1', '2022-06-25 08:21:09'),
(9, 3320988100, 'Sean Burks', 'SeanBurks1', '2022-06-25 08:21:43'),
(10, 530080513, 'Nikita Blundell', 'NikitaBlundell1', '2022-06-25 08:22:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addetails`
--
ALTER TABLE `addetails`
  ADD PRIMARY KEY (`Ad_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date` (`date`),
  ADD KEY `user_name` (`user_name`),
  ADD KEY `user_id` (`user_id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addetails`
--
ALTER TABLE `addetails`
  MODIFY `Ad_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
